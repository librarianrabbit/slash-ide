#ifndef UTILS_H
#define UTILS_H

class QString;

QString formatByteUnit(double& bytes);
QString unespace(const QString& text);

#endif // UTILS_H
