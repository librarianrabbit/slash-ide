#include "slashapivar.h"
#include "slashapi.h"

SlashAPIVar::SlashAPIVar(QObject* parent) :
    SlashAPIObject(parent)
{
}

SlashAPIVar::~SlashAPIVar()
{
}
